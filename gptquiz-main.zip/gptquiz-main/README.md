# GPTQuiz
Neste Jogo você poderá escolher o tema que deseja testar os seus conhecimentos.
Porém, o diferencial deste jogo é que ele usa o Chat GPT como motor de Inteligência Artificial.

![game](https://github.com/elieserDev/gptquiz/blob/main/gptquiz.png?raw=true)

![playgame](https://github.com/elieserDev/gptquiz/blob/main/playgame.png?raw=true)
